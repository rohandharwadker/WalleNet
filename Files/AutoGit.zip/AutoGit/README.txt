AutoGit 2.0.0 by WalleNet
All Rights Reserved

#### Installation Info ####
The .exe file is located in the 'Dist' folder.
If this doesn't work, delete the 'Dist', 'Build', and '.spec' directories and use pyinstaller
to reinstall the application:

In the 'AutoGit' directory, run the following command:

pyinstaller -w --onedir AutoGit.py

You may need to install the following modules:
-tkinter
-PIL
-pyautogui

For further comments/concerns email us at rohand.wallenet@gmail.com