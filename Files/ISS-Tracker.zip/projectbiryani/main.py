import requests
from PIL import Image, ImageTk
import time
import turtle

ISS_URL = 'http://api.open-notify.org/iss-now.json'
ASTROS_URL = 'http://api.open-notify.org/astros.json'


def getISSInfo(): # Get ISS Info
	r = requests.get(url = ISS_URL)
	data = r.json()
	return data

def getAstrosInfo(): # Get People Info
	r = requests.get(url = ASTROS_URL)
	data = r.json()
	return data

def getCoordinates(): # Extract Coordinates from ISS Info
	data = getISSInfo()
	latlonDict = data['iss_position']
	return (latlonDict['latitude'],latlonDict['longitude'])

def getAstros(): # Extract People from People Info
	data = getAstrosInfo()
	astrosList = data['people']
	retList = []
	for item in astrosList:
		if item['craft'] == 'ISS':
			retList.append(item['name'])
	return (retList)

def printLocation():
	coordinates = getCoordinates()
	print("The International Space Station is currently at position: ("+coordinates[0]+","+coordinates[1]+")")

def printAstronauts():
	people = getAstros()
	peopleStr = "Currently aboard the International Space Station: "
	for person in people:
		peopleStr += person + ", "
	peopleStr = peopleStr[:-2]
	print(peopleStr)

# Print Astronauts
print('\n')
printLocation()
printAstronauts()

# Create Map

screen = turtle.Screen()

screen.setup(720,360)
screen.setworldcoordinates(-180,-90,180,90)
screen.bgpic("map.gif")

screen.register_shape("satellite.gif")
iss = turtle.Turtle()
iss.shape("satellite.gif")
iss.setheading(90)
iss.penup()

while True:
	lon = float(getCoordinates()[1])
	lat = float(getCoordinates()[0])
	iss.goto(lon,lat)
	time.sleep(.1)