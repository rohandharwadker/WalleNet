import webbrowser
import os
from config import *
from tkinter import *
import subprocess



def call(event=""): # Decide what to do with current typed text
    data = e.get().lower()
    word_list = data.split()
    destroy = True

    # Show All Programs (Only works with Shell)
    if ('showall' in data):
        programlist = []
        programitems = list(programs.items())

        # Get all extras and programs and append them to the programlist
        for i in range(len(extras)):
            programlist.append(extras[i])
        for i in range(len(programitems)):
            programlist.append(programitems[i][0])
        print(programlist)

    # Settings (Must be before calculation)
    elif ("settings" in data):
        page = word_list[0]
        os.system("start ms-settings:"+page)

    elif ("explorer" in data):
        page = word_list[0]
        os.system("explorer")

    # Calculations
    elif ("+" in data or "-" in data or "/" in data or "*" in data):
        try:
            data = data.replace(" ","")
            data = data.replace("+"," + ")
            data = data.replace("-"," - ")
            data = data.replace("*"," * ")
            data = data.replace("/"," / ")
            word_list = data.split()
            answer = calculate(data)
            destroy = False
            e.delete(0,END)
            e.insert(0,str(answer))
            e.selection_range(0,END)
        except Exception as j:
            print("calculation failed:\n"+str(j))

    # Open Website
    elif ('.com' in data or '.org' in data or '.net' in data or '.io' in data):
        if ('.com' in data):
            dtype = ".com"
        elif ('.org' in data):
            dtype = ".org"
        elif ('.net' in data):
            dtype = '.net'
        elif ('.io' in data):
            dtype = '.io'
        res = list(filter(lambda x: dtype in x, word_list))
        res = " ".join(res)
        url = res
        print("Opening "+res+" in Chrome...")
        webbrowser.get(BROWSER_PATH).open(url)

    # Google Search
    elif (word_list[0] == "g"):
        search = data[2:]
        search = search.replace(" ","+")
        webbrowser.get(BROWSER_PATH).open("https://google.com/search?q="+search)

    # YouTube Search
    elif (word_list[0] == "yt"):
        search = data[2:]
        search = search.replace(" ","+")
        webbrowser.get(BROWSER_PATH).open("https://youtube.com/search?q="+search)

    # Shutdown Options
    elif (word_list[0] == "shutdown"):
        subprocess.call("shutdown /s")
    elif (word_list[0] == "lock"):
        subprocess.call("rundll32.exe user32.dll,LockWorkStation")
    elif (word_list[0] == "restart"):
        subprocess.call("shutdown /r")
    elif (word_list[0] == "logoff"):
        subprocess.call("shutdown /l")

    # Quit
    elif (word_list[0] == "exit"): 
        destroy = True

    # Open Program
    else:
        word_list = data.split()
        program_name = word_list[0].lower()
        if (program_name in programs):
            file = programs[program_name]
            print('Opening '+word_list[0])
            os.startfile(file)
        else:
            print("No program or website found called '"+str(data)+"'")
            destroy = False
            
    # Close Program if not a calculation, etc.
    if (destroy):
        s = open("QL-savedata.txt","r")
        savedtext = s.read()
        f = open("QL-savedata.txt","w")
        if (e.get() != "exit"):
            f.write(str(e.get()))
        else:
            f.write(savedtext)
        f.close()
        root.destroy()

def altCall(event=""): # Decide what to do with current typed text in ALT
    data = altProgram.cget("text")
    word_list = data.split()
    destroy = True

    # Show All Programs (Only works with Shell)
    if ('showall' in data):
        programlist = []
        programitems = list(programs.items())

        # Get all extras and programs and append them to the programlist
        for i in range(len(extras)):
            programlist.append(extras[i])
        for i in range(len(programitems)):
            programlist.append(programitems[i][0])
        print(programlist)

    # Settings (Must be before calculation)
    elif ("settings" in data):
        page = word_list[0]
        os.system("start ms-settings:"+page)

    elif ("explorer" in data):
        page = word_list[0]
        os.system("explorer")

    # Calculations
    elif ("+" in data or "-" in data or "/" in data or "*" in data):
        try:
            data = data.replace(" ","")
            data = data.replace("+"," + ")
            data = data.replace("-"," - ")
            data = data.replace("*"," * ")
            data = data.replace("/"," / ")
            word_list = data.split()
            answer = calculate(data)
            print(str(answer))
            destroy = False
            e.delete(0,END)
            e.insert(0,str(answer))
            e.selection_range(0,END)
        except Exception as j:
            print("calculation failed:\n"+str(j))

    # Open Website
    elif ('.com' in data or '.org' in data or '.net' in data or '.io' in data):
        if ('.com' in data):
            dtype = ".com"
        elif ('.org' in data):
            dtype = ".org"
        elif ('.net' in data):
            dtype = '.net'
        elif ('.io' in data):
            dtype = '.io'
        res = list(filter(lambda x: dtype in x, word_list))
        res = " ".join(res)
        url = res
        print("Opening "+res+" in Chrome...")
        webbrowser.get(BROWSER_PATH).open(url)

    # Google Search
    elif (word_list[0] == "g"):
        search = data[2:]
        search = search.replace(" ","+")
        webbrowser.get(BROWSER_PATH).open("https://google.com/search?q="+search)

    # YouTube Search
    elif (word_list[0] == "yt"):
        search = data[2:]
        search = search.replace(" ","+")
        webbrowser.get(BROWSER_PATH).open("https://youtube.com/search?q="+search)

    # Shutdown Options
    elif (word_list[0] == "shutdown"):
        subprocess.call("shutdown /s")
    elif (word_list[0] == "lock"):
        subprocess.call("rundll32.exe user32.dll,LockWorkStation")
    elif (word_list[0] == "restart"):
        subprocess.call("shutdown /r")
    elif (word_list[0] == "logoff"):
        subprocess.call("shutdown /l")

    # Quit
    elif (word_list[0] == "exit"): 
        destroy = True

    # Open Program
    else:
        word_list = data.split()
        program_name = word_list[0].lower()
        if (program_name in programs):
            file = programs[program_name]
            print('Opening '+word_list[0])
            os.startfile(file)
        else:
            print("No program or website found called '"+str(data)+"'")
            destroy = False
            
    # Close Program if not a calculation, etc.
    if (destroy):
        s = open("QL-savedata.txt","r")
        savedtext = s.read()
        f = open("QL-savedata.txt","w")
        if (altProgram.cget("text") != "exit"):
            f.write(str(altProgram.cget("text")))
        else:
            f.write(savedtext)
        f.close()
        root.destroy()

def lastCall(event=""): # Open last program
    e.delete(0,END)
    e.insert(0,lastCommand.lower())
    call()


def calculate(data): # Handles calculations
    word_list = data.split()
    if("+" in data):
        numOne = float(word_list[0])
        numTwo = float(word_list[2])
        answer = numOne + numTwo
    elif("-" in data):
        numOne = float(word_list[0])
        numTwo = float(word_list[2])
        answer = numOne - numTwo
    elif("*" in data):
        numOne = float(word_list[0])
        numTwo = float(word_list[2])
        answer = numOne * numTwo
    elif("/" in data):
        numOne = float(word_list[0])
        numTwo = float(word_list[2])
        answer = numOne / numTwo
    return(answer)



def autofill(event=""): # Autofill to any programs or extras when any key is pressed
    currenttext = e.get()
    currentlength = len(currenttext)
    programlist = []
    programitems = list(programs.items())
    matching = []
    # Get all extras and programs and append them to the programlist
    for i in range(len(extras)):
        programlist.append(extras[i])
    for i in range(len(programitems)):
        programlist.append(programitems[i][0])

    # Shorten all values of programlist to length of the current typed text
    programlistshortened = []
    for i in range(len(programlist)):
        programshortened = programlist[i][:currentlength]
        programlistshortened.append(programshortened)
    
    # If a shortened value matches what is typed, add it to 'matching' list
    if currentlength != 0:
        for i in range(len(programlistshortened)):
            if currenttext == programlistshortened[i]:
                matching.append(programlist[i])
                indexStop = i

    matchingLengthOrder = sorted(matching, key=len)
    try:
        p = matchingLengthOrder[0]
    except:
        altProgram.configure(text="")
    e.insert(currentlength,p[currentlength:])
    e.select_range(currentlength,END)
    if (len(matchingLengthOrder) > 1):
        p = matchingLengthOrder[1]
        altProgram.configure(text=p)
    else:
        altProgram.configure(text="")



"""

------------------------------------- Main Program Starts Here -------------------------------------

"""



# Setup window
root = Tk()
root.title("QuickLaunch")
root.geometry("600x200")
root.configure(bg="#303030",bd=7)
root.resizable(width=False,height=False)
root.overrideredirect(1)

# Create entry and fill with any saved text
e = Entry(root,width=100,font="Bahnschrift 24",bg="#292929",fg="#ffffff",bd="5",relief=FLAT)
e.pack()
try:
    s = open("QL-savedata.txt","r")
    savedtext = s.read()
except:
    savedtext = "QuickLaunch"
e.insert(0,savedtext)
e.focus_set()
e.bind("<FocusIn>", e.selection_range(0,END))

# Alt Program
altProgram = Label(text="",anchor="w",width=100,font="Bahnschrift 24",bg="#252525",fg="#ffffff",bd=5,relief=FLAT)
altProgram.pack()

# Create menu
menuLabel=Label(text="[Return] Launch 1        [Shift-Return] Launch 2        [Alt-Return] Launch Recent",font="Bahnschrift 8",bg="#303030",fg="#ffffff",bd=10)
menuLabel.pack()
lastCommand = "-"
if (savedtext != ""):
    lastCommand = savedtext
    lCList = list(lastCommand)
    lCList[0] = lCList[0].upper()
    lastCommand = "".join(lCList)
lastActionButton = Button(root,text="Launch Recent: "+lastCommand,font="Bahnschrift 18",width=100,bg="#292929",activebackground="#202020",fg="#ffffff",activeforeground="#ffffff",bd=0,command=lastCall)
lastActionButton.pack()

# Call the 'callAlt' function when <Alt> is pressed
root.bind('<Shift-Return>',altCall)

# Call the 'callLast' function when <Tab> is pressed
root.bind('<Alt-Return>',lastCall)

# Call the 'call' function when <Return> is pressed
root.bind('<Return>',call)

# Call the 'autofill' function when any key in 'keys' is pressed
keys="abcdefghijklmnopqrstuvwxyz-"
keys = list(keys)
for key in keys:
    root.bind(key,autofill)

# Run Tk
root.mainloop()